<!DOCTYPE html>
<html>
    <head>
        <meta charset='UTF-8' />
        <title>Title Website</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <link href="" rel="icon"/>


        <link href="css/reset.css" rel="stylesheet"/>
        <link href="css/style.css" rel="stylesheet"/>
        <script src="js/jquery-1.8.0.min.js"></script>
        <script src="js/main_1.js"></script>
    </head>
    <body>
    <span style="display:none" class="num_click">0</span>
    <div class="container">
        <p class="count_down"></p>
        <div class="content">
            <ul class="game">
                <li class="slot_1"><span>0</span></li>
                <li class="slot_2"><span>0</span></li>
                <li class="slot_3"><span>0</span></li>
            </ul>
        </div>
    </div>
    </body>
</html>